# 📱 Mobile Screen 08: Onboarding Audit & Approval Status

## 📍 File & Route Specification
- **File Path**: `mobile/app/(onboarding)/pending.tsx`
- **Route URL**: `/(onboarding)/pending`
- **Access Level**: Authenticated Pending Vendor

---

## 🎯 Purpose & Business Logic
Displays real-time compliance review status for newly submitted vendor onboarding applications. Features automatic background polling (`every 5s`) to check when GlowVAI compliance team approves GSTIN, PAN, and store location.

---

## 🎨 UI & Layout Specification
- **Canvas Background**: Pure White (`#FFFFFF`).
- **Status Indicator Card**: Soft amber card (`#FFFBEB`) with clock icon and text `"Application Under Review"`.
- **Audit Steps Checklist**:
  - GSTIN & PAN Document Verification (`Verified ✓`)
  - Bank Account Penny Drop Test (`Verified ✓`)
  - Physical Store Location & Geo-Fence Check (`In Progress ⏳`)
- **Help Desk Action**: Button to contact GlowVAI Merchant Support Desk via phone/WhatsApp.

---

## ⚡ Data Flow & API Hooks
- Polling Hook: `vendorApi.getProfileStatus(vendorId)` every 5,000ms.
- Auto-Route: On status `'APPROVED'`, sets `vendor_registered: 'true'` in `AsyncStorage` and redirects to `/(vendor)/home`.

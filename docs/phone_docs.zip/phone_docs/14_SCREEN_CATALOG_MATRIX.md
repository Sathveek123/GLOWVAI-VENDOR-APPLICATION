# 📱 Mobile Screen 14: Catalog Matrix & Live Stock Steppers

## 📍 File & Route Specification
- **File Path**: `mobile/app/(vendor)/catalog.tsx`
- **Route URL**: `/(vendor)/catalog`
- **Access Level**: Authenticated Merchant

---

## 🎯 Purpose & Business Logic
The store inventory management console. Displays all skincare and cosmetics SKUs, stock levels, MRP/selling prices, shelf locations, and features quick stock steppers (`-` / `+`). When an SKU stock reaches 0, it automatically hides from live customer search in real-time.

---

## 🎨 UI & Layout Specification
- **Top Metrics Strip**: Total SKUs count, Low Stock count (`< 5`), Out of Stock count.
- **Search & Category Filter**: Search bar for product name / SKU code + category filter pills (Skincare, Makeup, Hair Care).
- **Product Card Item**:
  - Thumbnail image, product name, shade/variant, shelf location tag (`📍 A-01-05`).
  - MRP vs Selling Price display (e.g. `₹999` MRP `₹1,099`).
  - Live Stock Stepper (`-` count `+`).
  - Active / Inactive switch toggle.
- **Floating Action Button (FAB)**: `+ Add SKU` linking to `/(vendor)/add-sku`.

---

## ⚡ Data Flow & API Hooks
- Data Adapter: `fetchCatalogProducts()` (`USE_MOCK_CATALOG_EXTRAS`).
- Instant Stock Adjustment: `updateInventoryItem(productId, { stock: next })`.
- API Call: `inventoryApi.adjustStock(productId, delta)`.

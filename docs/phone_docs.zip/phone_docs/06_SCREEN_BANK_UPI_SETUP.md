# 📱 Mobile Screen 06: Step 3: Bank Account & UPI Setup

## 📍 File & Route Specification
- **File Path**: `mobile/app/(onboarding)/step-c.tsx`
- **Route URL**: `/(onboarding)/step-c`
- **Access Level**: Authenticated Onboarding Merchant

---

## 🎯 Purpose & Business Logic
Step 3 of onboarding. Configures the vendor's primary settlement bank account and optional UPI VPA handle for automated daily IMPS T+1 payouts. Validates IFSC code and verifies account holder name alignment with PAN identity.

---

## 🎨 UI & Layout Specification
- **Progress Tracker**: `ProgressSteps current={3}`.
- **Form Fields**:
  - Bank Name picker (Popular banks: HDFC, ICICI, SBI, Axis, Kotak)
  - Beneficiary Account Holder Name
  - Account Number (`TextInput` number-pad, masked display)
  - Confirm Account Number (Paste-blocked field)
  - 11-character IFSC Code (Auto resolves branch name e.g., Benz Circle, Vijayawada)
  - UPI VPA handle with "Verify Handle" button
- **Settlement Note Card**: Light blue banner (`#EFF6FF`) explaining daily 06:00 AM T+1 automated payouts.
- **Primary CTA**: *"Continue to Catalog Seed (Step 4 of 4)"*.

---

## ⚡ Data Flow & API Hooks
- `AsyncStorage.setItem('onb_step_c', JSON.stringify(bankData))`
- Validation: IFSC regex `/^[A-Z]{4}0[A-Z0-9]{6}$/` and account number equality match.

# 📱 Mobile Screen 03: SMS OTP Verification

## 📍 File & Route Specification
- **File Path**: `mobile/app/(auth)/otp.tsx`
- **Route URL**: `/(auth)/otp`
- **Access Level**: Public (Requires phone query parameter)

---

## 🎯 Purpose & Business Logic
Verifies the SMS OTP code sent to the vendor's mobile number. Features 4-digit auto-advancing input boxes, 30-second resend timer countdown, 3-attempt limit lockout, and a test OTP chip (`4892`) for development testing.

---

## 🎨 UI & Layout Specification
- **Canvas Background**: Pure White (`#FFFFFF`).
- **Header**: Back arrow, title "SMS Verification", and target phone display (`+91 98XXX XX210`) with edit link.
- **4-Digit Input**: Styled 48px square boxes with numeric keyboard and active blue focus border (`#1D4ED8`).
- **Resend Countdown Widget**: 30-second timer. Enables "Resend SMS" action upon reaching 0s.
- **Test OTP Chip**: Amber chip (`#FEF3C7`) with text `"💡 Test OTP: Tap to autofill 4892"`.
- **Primary CTA**: *"Verify & Continue"*.

---

## ⚡ Data Flow & API Hooks
- **API Call**: `authApi.verifyOtp(phone, otp)`
- **Storage**: Commits `vendorId`, `sessionToken`, and `vendor_registered` to `AsyncStorage`.
- **State**: Calls `useVendorStore.getState().setVendor(profile)`.
- **Routing**: Redirects to `/(vendor)/home` if approved, or `/(onboarding)/step-a` if new store registration.

---

## 🔒 Security Rules
- Maximum 3 incorrect attempts before 15-minute temporary security lockout.

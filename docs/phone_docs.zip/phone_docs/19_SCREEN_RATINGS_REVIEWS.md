# 📱 Mobile Screen 19: Ratings & Customer Reviews

## 📍 File & Route Specification
- **File Path**: `mobile/app/(vendor)/reviews.tsx`
- **Route URL**: `/(vendor)/reviews`
- **Access Level**: Authenticated Merchant

---

## 🎯 Purpose & Business Logic
Displays verified customer ratings and product quality reviews. Never hardcodes star ratings; all values (e.g. `4.8 ★`, 142 reviews) are loaded dynamically from data. Allows vendors to send official merchant replies to customer reviews.

---

## 🎨 UI & Layout Specification
- **Rating Summary Card**: Large average star score (`4.8 ★`), verified review count, and breakdown bars (Product Quality, Packaging, Speed).
- **Review List Items**:
  - Customer name (`Priya S.`), star score (`5 ★`), review text (`"Authentic product! Sealed tight."`), and ordered item name.
  - *"Reply to Review"* button opening a text input drawer.

---

## ⚡ Data Flow & API Hooks
- Data Adapter: `fetchCustomerReviews()` (`USE_MOCK_SUPPORT_EXTRAS`).
- API Call: `supportApi.replyReview(reviewId, replyText)`.

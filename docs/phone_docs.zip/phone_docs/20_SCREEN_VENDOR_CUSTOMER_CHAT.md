# 📱 Mobile Screen 20: Vendor-Customer Support Chat

## 📍 File & Route Specification
- **File Path**: `mobile/app/(vendor)/messages.tsx`
- **Route URL**: `/(vendor)/messages`
- **Access Level**: Authenticated Merchant

---

## 🎯 Purpose & Business Logic
Order-scoped customer messaging thread. Enables vendors to communicate with customers regarding active orders (e.g., packing status or seal confirmation) while strictly enforcing contact privacy rules.

---

## 🔒 Privacy & Safety Rules (NON-NEGOTIABLE)
- **Automatic Contact Blocking**: Regex guards block transmission of phone numbers (`/\d{10}/`), email addresses, external URLs, and UPI handles inside chat messages.
- Displays privacy banner `"🔒 Order-Scoped Privacy Active: Phone numbers and links are automatically blocked."`

---

## 🎨 UI & Layout Specification
- **Header**: Active Order ID (`#GV-9912`), customer name (`Priya S.`), order status (`PACKING`).
- **Message Bubbles**: Left-aligned customer messages (Slate `#F8FAFC`), right-aligned vendor replies (Royal Blue `#1D4ED8`).
- **Input Bar**: Message `TextInput` with send icon.

---

## ⚡ Data Flow & API Hooks
- Data Adapter: `fetchOrderChatThread(orderId)` (`USE_MOCK_SUPPORT_EXTRAS`).
- Regex Privacy Guard: `sanitizeChatMessage(text)`.

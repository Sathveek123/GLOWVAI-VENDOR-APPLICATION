# 📱 Mobile Screen 11: Orders List & History

## 📍 File & Route Specification
- **File Path**: `mobile/app/(vendor)/orders.tsx`
- **Route URL**: `/(vendor)/orders`
- **Access Level**: Authenticated Merchant

---

## 🎯 Purpose & Business Logic
Provides a tabbed overview of all active and historical customer orders. Enables vendors to quickly filter orders by status (New, Accepted, Ready, Completed, Cancelled) and monitor fulfillment SLAs.

---

## 🎨 UI & Layout Specification
- **Canvas Background**: Pure White (`#FFFFFF`).
- **Horizontal Tab Bar**:
  - `New` (Pending acceptance)
  - `Accepted` (Being packed)
  - `Ready` (Packed / Ready for rider pickup)
  - `Completed` (Delivered)
  - `Cancelled` (Customer/Platform cancelled)
- **Order List Cards**: Order ID, item count, timestamp (`timeAgo`), total payout amount, and status pill (`StatusPill`).
- **Pull-to-Refresh**: `RefreshControl` support for manual queue sync.

---

## ⚡ Data Flow & API Hooks
- Store Selector: `useVendorStore((state) => state.orders)`
- API Fetch: `ordersApi.getAll({ storeId })`
- Navigation: Tapping any row opens `/(vendor)/order-detail` with `orderId`.

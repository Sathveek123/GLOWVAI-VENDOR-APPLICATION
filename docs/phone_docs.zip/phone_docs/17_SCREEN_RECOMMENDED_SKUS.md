# 📱 Mobile Screen 17: AI Skincare Demand SKUs

## 📍 File & Route Specification
- **File Path**: `mobile/app/(vendor)/recommended-skus.tsx`
- **Route URL**: `/(vendor)/recommended-skus`
- **Access Level**: Authenticated Merchant

---

## 🎯 Purpose & Business Logic
AI-driven inventory recommendation engine for cosmetics retailers. Analyzes local quick-commerce demand trends around the vendor's geo-location (e.g. Benz Circle, Vijayawada) and suggests high-margin, trending beauty SKUs to add to stock.

---

## 🎨 UI & Layout Specification
- **Header Banner**: Light blue AI insights card (`#EFF6FF`) with text `"High-Demand Beauty Trends in Your Area"`.
- **Recommended SKU Cards**:
  - Image, Product Name, Brand (e.g., CeraVe Hydrating Cleanser, COSRX Snail Mucin).
  - Estimated Monthly Demand (e.g., `⚡ +140 orders/mo in Vijayawada`).
  - Expected Margin (e.g., `22% Net Margin`).
  - Action Button: *"Add to Store Inventory"* (1-tap seed).

---

## ⚡ Data Flow & API Hooks
- Data Adapter: `fetchRecommendedSkus()` (`USE_MOCK_CATALOG_EXTRAS`).
- 1-Tap Add Action: Inserts product directly into `inventory` store array.

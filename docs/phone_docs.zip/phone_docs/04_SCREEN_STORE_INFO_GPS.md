# 📱 Mobile Screen 04: Step 1: Store Info & GPS Pinning

## 📍 File & Route Specification
- **File Path**: `mobile/app/(onboarding)/step-a.tsx`
- **Route URL**: `/(onboarding)/step-a`
- **Access Level**: Authenticated Onboarding Merchant

---

## 🎯 Purpose & Business Logic
Step 1 of the 4-step merchant onboarding flow. Collects essential store identity details (Store Name, Owner Name, Locality, City, Pincode, Operating Hours) and pins exact store latitude/longitude coordinates on a map for geospatial quick-commerce dispatch.

---

## 🎨 UI & Layout Specification
- **Progress Tracker**: 4-step top progress bar (`ProgressSteps current={1}`).
- **Form Fields**:
  - Store / Shop Name (`TextInput`)
  - Owner / Merchant Full Name (`TextInput`)
  - Locality / Commercial Area (e.g., Benz Circle)
  - City & Pincode (e.g., Vijayawada 520010)
  - Opening & Closing Time pickers (default 09:00 AM - 11:00 PM)
- **Map Pin Widget**: Interactive map view with draggable pin marker defaulting to Vijayawada coordinates (`16.5062, 80.6480`).
- **Primary CTA**: *"Continue to Tax Verification (Step 2 of 4)"*.

---

## ⚡ Data Flow & API Hooks
- `AsyncStorage.setItem('onb_step_a', JSON.stringify(formData))`
- Validation: Enforces non-empty store name, valid 6-digit Indian pincode, and verified GPS pin coordinates.

# 📱 Mobile Screen 01: Root Splash & Session Router

## 📍 File & Route Specification
- **File Path**: `mobile/app/index.tsx`
- **Route URL**: `/` (Root Index Entry)
- **Access Level**: Public / Unauthenticated Evaluator

---

## 🎯 Purpose & Business Logic
The initial entry point of the GlowVAI Vendor Mobile Application. It displays the brand identity aura and evaluates active session tokens from `AsyncStorage`. Automatically routes vendors to either:
1. `/(vendor)/home` if a valid session token & verified vendor profile exist.
2. `/(auth)/login` if no session is stored or token has expired.
3. `/(onboarding)/pending` if onboarding verification is incomplete.

---

## 🎨 UI & Layout Specification
- **Canvas Background**: Pure White (`#FFFFFF`) with centered layout.
- **Brand Logo Aura**: Royal Blue (`#1D4ED8`) brand lettermark inside a soft rounded container (`Radius: 20`).
- **App Title**: GlowVAI Vendor App in Syne/Inter typography (`#0F172A`).
- **Loading Indicator**: Smooth activity indicator in royal blue (`#1D4ED8`).

---

## ⚡ Data Flow & API Hooks
- `AsyncStorage.getItem('vendor_registered')`
- `AsyncStorage.getItem('session_token')`
- `useVendorStore.getState().setVendor(storedProfile)`

---

## ♿ Accessibility & Edge Cases
- **Slow Storage Read**: Renders splash screen until token check resolves (max 1.5s fallback timeout).
- **Network Disconnect**: Operates offline based on cached local storage session.

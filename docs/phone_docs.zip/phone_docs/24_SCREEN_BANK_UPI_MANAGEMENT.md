# 📱 Mobile Screen 24: Bank Account & UPI Management

## 📍 File & Route Specification
- **File Path**: `mobile/app/(vendor)/bank-edit.tsx`
- **Route URL**: `/(vendor)/bank-edit`
- **Access Level**: Authenticated Merchant

---

## 🎯 Purpose & Business Logic
Lets vendors safely view and modify payout bank account and UPI details. All changes require SMS OTP re-authentication and trigger a 24-hour security cooling period with payout hold protection.

---

## 🔒 Security Rules (NON-NEGOTIABLE)
- Full account numbers are never displayed after submission; only `XXXXXX4589`.
- VPA handles are masked (`glow****@hdfcbank`) with a copy-free design.
- Confirm account number field blocks copy/paste.

---

## 🎨 UI & Layout Specification
- **View State**: Bank card with initial logo, masked account number, IFSC code (`HDFC0001234`), branch, and `Verified` status pill.
- **3-Step Edit Flow Modal**:
  - *Step 1 (OTP)*: 6-digit SMS OTP input, 30s resend timer, 3-attempt lockout limit, test OTP chip (`4892`).
  - *Step 2 (New Details)*: Beneficiary name, bank name, account number, paste-blocked confirm field, IFSC branch lookup, UPI VPA verify button.
  - *Step 3 (Review & Submit)*: Comparison card of current vs new details, mandatory confirmation checkbox, and 24h cooling policy banner.

---

## ⚡ Data Flow & API Hooks
- Finance Adapter: `fetchBankAccountDetails()`, `fetchBankPolicy()`, `fetchRecentBankChanges()`.

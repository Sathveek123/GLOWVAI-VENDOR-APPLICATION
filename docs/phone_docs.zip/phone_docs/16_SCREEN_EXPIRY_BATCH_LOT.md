# 📱 Mobile Screen 16: Expiry & Batch Lot Tracker (FEFO)

## 📍 File & Route Specification
- **File Path**: `mobile/app/(vendor)/expiry.tsx`
- **Route URL**: `/(vendor)/expiry`
- **Access Level**: Authenticated Merchant

---

## 🎯 Purpose & Business Logic
FEFO (First Expiry, First Out) inventory management console designed specifically for skincare and cosmetics. Tracks manufacturing dates, lot numbers, and expiry dates to prevent expired product sales and trigger early clearance discounts.

---

## 🎨 UI & Layout Specification
- **Critical Expiry Banner**: Amber banner (`#FFFBEB`) highlighting batches expiring within 30 days.
- **Segment Tabs**: `Needs Action` (Critical / Expiring), `All Batches`, `Cleared`.
- **Batch Card Items**:
  - Product Name, Lot Code (e.g. `LOT-CRV-991`), Shelf Location tag (`📍 A-01-05`).
  - Status Pill: `Critical` (Red `#DC2626`), `Near Expiry` (Amber `#D97706`), `Good` (Green `#16A34A`).
  - Expiry Date (MM/YYYY) and Remaining Quantity.
  - Action Buttons: *"Apply Discount"* / *"Mark Cleared"*.
- **Add Batch Modal**: Modal to register new incoming shipment lots.

---

## ⚡ Data Flow & API Hooks
- Data Adapter: `fetchBatches()` (`USE_MOCK_CATALOG_EXTRAS`).
- Logic: Orders batches chronologically by `expiryDate` ascending for FEFO compliance.

# 📱 Mobile Screen 22: Weekly Bank Settlement (UTR Receipts)

## 📍 File & Route Specification
- **File Path**: `mobile/app/(vendor)/payout-detail.tsx` & `mobile/app/(vendor)/settlements.tsx`
- **Route URL**: `/(vendor)/payout-detail`
- **Access Level**: Authenticated Merchant

---

## 🎯 Purpose & Business Logic
Bank settlement and UTR receipt reconciliation center. Shows historical bank transfer payouts, exact UTR numbers, settlement dates, and destination bank account last 4 digits.

---

## 🎨 UI & Layout Specification
- **Next Payout Card**: Blue tint card (`#EFF6FF`) showing expected payout date, amount, and destination (`HDFC Bank XXXX4589`).
- **Settlement List**:
  - Settlement cycle (e.g. `Week 40`), date range, StatusPill (`Paid`, `Processing`, `Failed`).
  - UtrChip: Monospace UTR code (`UTR-4021-8856-3321`) with 1-tap copy button & copied toast.
- **Detailed Invoice Breakdown**: Itemized gross sales, platform fee, GST on fee, TCS, TDS, adjustments, and final net payout.
- **Print Receipt**: Styled printable receipt formatted for clean A4 printing.

---

## ⚡ Data Flow & API Hooks
- Finance Adapter: `fetchSettlements()` (`USE_MOCK_FINANCE_EXTRAS`).
- Monospace UTR Copy: `Clipboard.setString(utr)`.

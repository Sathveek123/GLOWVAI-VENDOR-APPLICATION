# 📱 Mobile Screen 12: Order Detail & Substitution

## 📍 File & Route Specification
- **File Path**: `mobile/app/(vendor)/order-detail.tsx`
- **Route URL**: `/(vendor)/order-detail`
- **Access Level**: Authenticated Merchant

---

## 🎯 Purpose & Business Logic
Detailed single-order view. Allows vendors to inspect ordered items, verify shelf location tags (`ShelfTag`), manage customer item substitutions when an SKU is out of stock, and advance order status.

---

## 🎨 UI & Layout Specification
- **Header**: Back arrow, Order ID (`#GV-9912`), and order status pill.
- **Privacy Compliance**: Displays customer first name + area only (`Priya S. • Benz Circle`). Phone number and full address are masked for privacy.
- **Item Checklist Card**:
  - Item name, quantity, price, and shelf location tag (`📍 Shelf A-01-05`).
  - Out-of-stock toggle triggering the Customer Substitution Drawer.
- **Substitution Drawer**: Recommends shade or size variants (e.g. 10% Niacinamide 30ml -> 50ml or alternate brand) with customer approval status.
- **Payment & Pricing Breakdown**: Items subtotal, platform commission, GST, and vendor net earnings.
- **Action Button**: *"Start Packing Order"* / *"Mark Ready for Rider Pickup"*.

---

## ⚡ Data Flow & API Hooks
- API Call: `ordersApi.getById(orderId)`
- Status Advance API: `ordersApi.prepare(orderId)` / `ordersApi.pack(orderId)`.

# 📱 Mobile Screen 18: Customer Return Requests & Inspection

## 📍 File & Route Specification
- **File Path**: `mobile/app/(vendor)/returns.tsx`
- **Route URL**: `/(vendor)/returns`
- **Access Level**: Authenticated Merchant

---

## 🎯 Purpose & Business Logic
Manages customer return and refund requests for damaged, incorrect, or expired beauty items. Vendors inspect unboxing photos, verify return reasons, and recommend approval or rejection to GlowVAI support.

---

## 🎨 UI & Layout Specification
- **Return Request List**: Order ID (`#GV-9908`), customer name (privacy masked), return reason (e.g., "Leaking Bottle Seal"), requested refund amount.
- **Photo Inspection Modal**: High-res unboxing image preview submitted by customer.
- **Action Buttons**:
  - *"Recommend Full Refund"* (Primary Blue `#1D4ED8`)
  - *"Reject Return / Escalate to GlowVAI Support"* (Danger Red `#DC2626`)

---

## ⚡ Data Flow & API Hooks
- Data Adapter: `fetchReturnRequests()` (`USE_MOCK_SUPPORT_EXTRAS`).
- API Call: `supportApi.processReturn(returnId, decision)`.

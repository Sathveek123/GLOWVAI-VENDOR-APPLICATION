# 📱 Mobile Screen 15: Add / Edit SKU (Shades & Variants)

## 📍 File & Route Specification
- **File Path**: `mobile/app/(vendor)/add-sku.tsx`
- **Route URL**: `/(vendor)/add-sku`
- **Access Level**: Authenticated Merchant

---

## 🎯 Purpose & Business Logic
Enables vendors to create new beauty product listings or edit existing SKUs. Captures shade swatches, size volume variants (e.g., 30ml, 50ml), MRP, selling price, GST slab (18% / 5%), and physical shelf location.

---

## 🎨 UI & Layout Specification
- **Header**: Back arrow, title "Add New Product SKU".
- **Form Sections**:
  - Basic Info: Product Name, Brand, Category, Description.
  - Shade & Variant Selector: Color swatch picker for makeup foundations/lipsticks or volume picker (30ml, 50ml, 100ml).
  - Pricing & GST: Selling Price (INR), MRP, GST Rate (18% / 5%).
  - Inventory & Storage: Initial Stock On Hand, Low Stock Threshold, Shelf Location (`A-01-05`).
  - Product Image Picker: 3-image upload drop zone.
- **Primary CTA**: *"Save Product SKU"*.

---

## ⚡ Data Flow & API Hooks
- API Call: `inventoryApi.create(productPayload)` / `inventoryApi.update(productId, payload)`.
- Store Update: Calls `addInventoryItem(newProduct)` in `useVendorStore`.

# 📱 Mobile Screen 25: Store Profile & KYC Dossier

## 📍 File & Route Specification
- **File Path**: `mobile/app/(vendor)/profile.tsx`
- **Route URL**: `/(vendor)/profile`
- **Access Level**: Authenticated Merchant

---

## 🎯 Purpose & Business Logic
Central management console for store identity, operating hours, verified documents, and merchant preferences. Replaces all legacy warehouse/duty terms with standard merchant retail wording.

---

## 🎨 UI & Layout Specification
- **Header Card**: Logo with camera upload badge, store name (`Sri Lakshmi Beauty Store`), store ID (`DS-VIJ-01`), city, rating & review count (`4.8 ★ (142 reviews)` from data), member since date.
- **Sub-Tabs**:
  1. `Store`: Name, owner, phone, email, description, street address, locality.
  2. `Hours`: 7-day weekly schedule (`HoursEditor`), open/close time pickers, copy Mon to all, special closures, live status preview line.
  3. `KYC`: Verification progress bar (`5 of 6 verified`), action needed banner for expiring licenses, masked numbers with 10s auto re-masking reveal buttons, replacement modal (5MB limit), privacy disclaimer line.
  4. `Bank`: Payout account summary link to Screen 24.
- **Logout Action**: Danger button opening confirmation dialog (`ConfirmDialog`).

---

## ⚡ Data Flow & API Hooks
- Finance Adapter: `fetchStoreProfile()`, `fetchKycDocuments()`.
- API Calls: `vendorApi.updateProfile(vendorId, data)`.

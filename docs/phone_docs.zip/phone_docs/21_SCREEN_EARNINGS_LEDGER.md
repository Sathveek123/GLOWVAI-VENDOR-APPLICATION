# 📱 Mobile Screen 21: Financial Revenue Ledger (88/12 Split)

## 📍 File & Route Specification
- **File Path**: `mobile/app/(vendor)/earnings.tsx`
- **Route URL**: `/(vendor)/earnings`
- **Access Level**: Authenticated Merchant

---

## 🎯 Purpose & Business Logic
Financial analytics and earnings ledger. Displays total gross sales, platform fulfillment fee (12%), vendor net earnings (88%), pending vs settled payouts, and daily order breakdown. All split percentages and amounts come directly from data without local local calculations.

---

## 🎨 UI & Layout Specification
- **Hero Card**: Vendor Net Earnings (`₹43,050.00`) in royal blue (`#1D4ED8`) with period label.
- **SplitBar Widget**: Two-segment bar visualizing vendor share (88% blue) vs GlowVAI fee (12% light blue).
- **Balance Strip**: `Pending` (earned, not settled) & `Settled` payout cards side by side.
- **EarningsChart**: Stacked daily bar chart with net earnings, gross sales, and order count toggles + "View as Table" toggle.
- **Daily Ledger List**: Grouped order rows with order ID, status pill, gross sales, fee, and net payout. Refunds display minus sign and icon.

---

## ⚡ Data Flow & API Hooks
- Finance Adapter: `fetchEarningsSummary()`, `fetchLedgerEntries()`.
- Money Formatting: `formatPaiseToINR(paise)`.

# 📱 Mobile Screen 13: Order Packing & Rider Handover

## 📍 File & Route Specification
- **File Paths**: `mobile/app/(vendor)/pack-order.tsx` & `mobile/app/(vendor)/ready-pickup.tsx`
- **Route URLs**: `/(vendor)/pack-order` & `/(vendor)/ready-pickup`
- **Access Level**: Authenticated Merchant

---

## 🎯 Purpose & Business Logic
Guides the vendor through the physical packing phase and rider handover. Enforces item verification, tamper-evident sealing confirmation, and generates the 4-digit pickup code / QR code shown to the GlowVAI delivery rider upon arrival.

---

## 🎨 UI & Layout Specification
- **Packing Checklist**: Interactive checkboxes per item to ensure 100% order accuracy before bag sealing.
- **Tamper-Evident Bag Seal Confirmation**: Required checkbox `"I confirm order is packed in tamper-evident sealed packaging"`.
- **Rider Pickup Card**:
  - Rider name & vehicle details (e.g. `Ramesh (EV Scooter AP-16-XX)`).
  - Estimated rider arrival timer (e.g. `Rider ETA: 3 mins`).
- **4-Digit Handover Pickup Code Box**: Prominent monospace display of pickup code (e.g. `CODE: 4892`) and dynamic QR code generated for rider scan.

---

## ⚡ Data Flow & API Hooks
- API Call: `ordersApi.readyForPickup(orderId)` & `ordersApi.dispatch(orderId)`.
- Socket Events: Listens for `RIDER_ARRIVED` notification.

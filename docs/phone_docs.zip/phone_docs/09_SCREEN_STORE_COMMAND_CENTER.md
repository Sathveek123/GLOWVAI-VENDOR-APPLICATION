# 📱 Mobile Screen 09: Store Command Center ("Store Open / Paused")

## 📍 File & Route Specification
- **File Path**: `mobile/app/(vendor)/home.tsx`
- **Route URL**: `/(vendor)/home`
- **Access Level**: Authenticated Merchant

---

## 🎯 Purpose & Business Logic
The main operational dashboard of the GlowVAI Vendor App. Lets merchants toggle their store duty status ("Store Open / Paused"), monitor live incoming quick-commerce orders, track daily gross sales and net payouts, inspect store quality metrics, and quickly adjust inventory stock.

---

## 🎨 UI & Layout Specification
- **Top Header**: Merchant avatar, store name (`Sri Lakshmi Beauty Store`), locality (`Benz Circle`), and customer app preview redirect button.
- **Duty Toggle Bar**: Prominent status toggle pill ("Store Open / Paused") with morphing green (`#00A300`) and red (`#D10000`) background animations.
- **Focal Metric Box**: Displays live gross sales (`₹48,920`) or total orders done.
- **3 Metric Cards**: Gross Sales, Active Duty Time, Net Payout (`₹43,050`).
- **2 Performance Gauges**: Duty Time Gauge & Store Quality Rating.
- **Daily Updates Section**:
  - Live Active Orders Queue
  - Quick Stock Steppers (`-` / `+`) for fast inventory adjustments

---

## ⚡ Data Flow & API Hooks
- `useVendorStore` hook: `vendor`, `orders`, `inventory`, `setOnlineStatus`.
- Socket Events: Listens for `ORDER_BROADCAST` and `ORDER_OFFER`.
- API Call: `vendorApi.setOnline(vendorId, isOnline)`.

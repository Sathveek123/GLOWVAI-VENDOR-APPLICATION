# 📱 Mobile Screen 10: Incoming Order Offer Modal (45s Lock)

## 📍 File & Route Specification
- **File Path**: `mobile/src/components/IncomingOrderModal.tsx`
- **Component**: `<IncomingOrderModal />`
- **Access Level**: Authenticated Merchant (Triggered by Socket event)

---

## 🎯 Purpose & Business Logic
High-priority audio-visual modal that pops up when a new quick-commerce customer order is offered to nearby vendors. Features a 45-second countdown timer and atomic SETNX Redis accept lock to ensure the first vendor to accept claims the order exclusively.

---

## 🎨 UI & Layout Specification
- **Modal Overlay**: High-contrast full-screen backdrop with loud incoming chime audio (`soundService.playIncomingOrderChime()`).
- **45s Countdown Bar**: Visual progress bar decreasing from 45s to 0s (`CountdownBar`).
- **Order Details Box**: Order ID (e.g. `#GV-9912`), customer name & area (`Priya S. • Benz Circle`), total items, and net vendor payout (`₹1,054.24`).
- **Action Buttons**:
  - *"⚡ ACCEPT ORDER NOW"* (Primary Royal Blue `#1D4ED8`)
  - *"Decline"* (Secondary Ghost Button)

---

## ⚡ Data Flow & API Hooks
- Socket Listener: `ORDER_OFFER` -> triggers modal & ringing sound.
- Accept API: `ordersApi.accept(orderId, vendorId)` -> acquires Redis lock.
- Decline API: `ordersApi.decline(orderId, vendorId)`.
- If another vendor claims it first: receives `ORDER_CLAIMED_BY_OTHER` socket notification and auto-dismisses modal.

# 📱 Mobile Screen 07: Step 4: Beauty Categories & Catalog Seed

## 📍 File & Route Specification
- **File Path**: `mobile/app/(onboarding)/step-d.tsx`
- **Route URL**: `/(onboarding)/step-d`
- **Access Level**: Authenticated Onboarding Merchant

---

## 🎯 Purpose & Business Logic
Final onboarding step. Vendors select their primary operating beauty categories (Skincare, Cosmetics & Makeup, Hair Care, Fragrances) and quickly seed popular top-selling SKUs into their live inventory with initial stock quantities.

---

## 🎨 UI & Layout Specification
- **Progress Tracker**: `ProgressSteps current={4}`.
- **Category Selection Chips**: Multi-select pills for beauty specialties.
- **Catalog Quick Seed List**:
  - Pre-populated top beauty SKUs (Minimalist 10% Niacinamide, Cetaphil Gentle Cleanser, Maybelline Fit Me Foundation, L'Oreal Paris Serum).
  - Checkbox toggle per product to include in store inventory.
  - Stock quantity stepper (`-` / `+`) per selected item.
- **Primary CTA**: *"Submit Store Onboarding Application"*.

---

## ⚡ Data Flow & API Hooks
- **API Call**: `vendorApi.submitOnboarding(fullPayload)`
- **State**: Populates `useVendorStore.getState().setInventory(initialItems)`.
- **Routing**: Redirects to `/(onboarding)/pending`.

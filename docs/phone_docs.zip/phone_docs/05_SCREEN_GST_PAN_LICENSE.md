# 📱 Mobile Screen 05: Step 2: GSTIN, PAN & License Upload

## 📍 File & Route Specification
- **File Path**: `mobile/app/(onboarding)/step-b.tsx`
- **Route URL**: `/(onboarding)/step-b`
- **Access Level**: Authenticated Onboarding Merchant

---

## 🎯 Purpose & Business Logic
Step 2 of onboarding. Captures tax identity numbers (GSTIN, PAN card) and regulatory trade/cosmetics retail licenses. Features automated GSTIN format validation and document photo attachment cards (`DocUploadCard`).

---

## 🎨 UI & Layout Specification
- **Progress Tracker**: `ProgressSteps current={2}`.
- **Form Fields**:
  - 15-digit GSTIN number (`37AAAAA0000A1Z5` uppercase validation)
  - 10-digit PAN number (`ABCDE1234F`)
  - Trade License / FSSAI number (optional)
  - Cosmetics Retail License number & expiry date picker
- **Document Photo Upload Cards**:
  - GST Certificate Upload Box (`UploadBox`)
  - Store Front Exterior Photo Upload Box
  - Owner Govt ID Upload Box
- **Primary CTA**: *"Save & Continue to Bank Setup (Step 3 of 4)"*.

---

## ⚡ Data Flow & API Hooks
- `AsyncStorage.setItem('onb_step_b', JSON.stringify(taxData))`
- Validation: Strict regex for GSTIN (`/^\d{2}[A-Z]{5}\d{4}[A-Z]{1}[A-Z\d]{1}[Z]{1}[A-Z\d]{1}$/`) and PAN (`/^[A-Z]{5}\d{4}[A-Z]{1}$/`).

# 📱 Mobile Screen 02: Vendor Mobile Login (+91)

## 📍 File & Route Specification
- **File Path**: `mobile/app/(auth)/login.tsx`
- **Route URL**: `/(auth)/login`
- **Access Level**: Public / Unauthenticated

---

## 🎯 Purpose & Business Logic
Enables beauty retailers and cosmetics vendors to enter their 10-digit Indian mobile number (`+91`) to initiate SMS OTP authentication. Validates input formatting and triggers backend OTP SMS dispatch.

---

## 🎨 UI & Layout Specification
- **Canvas Background**: Pure White (`#FFFFFF`).
- **Header Section**: GlowVAI Merchant Partner Portal logo & greeting text ("Welcome Back, Beauty Partner").
- **Mobile Input Box**: 
  - Fixed country code prefix `+91` in soft blue pill (`#EFF6FF`).
  - 10-digit numeric `TextInput` with focused royal blue border (`#1D4ED8`).
- **Primary CTA**: *"Send Verification Code"* (`PrimaryButton`, royal blue `#1D4ED8`).
- **Terms & Privacy Footer**: Disclaimer linking to GlowVAI Merchant Terms of Service.

---

## ⚡ Data Flow & API Hooks
- **Validation**: Regex check `/^[6-9]\d{9}$/` enforcing 10 valid Indian digits starting with 6, 7, 8, or 9.
- **API Call**: `authApi.sendOtp(phone)`
- **Navigation**: Navigates to `/(auth)/otp` passing `phone` parameter.

---

## ♿ Accessibility & Security Rules
- **Keyboard Type**: Enforces `keyboardType="phone-pad"`.
- **Privacy**: Mobile number formatted cleanly without exposing raw tokens in logs or analytics.
